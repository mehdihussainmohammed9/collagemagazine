package com.example.srkr.srkrmagazine;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class Home extends AppCompatActivity {

    MyDatabase myDatabase;
    RecyclerView recyclerView;
    Login login;
    String s;
    ArrayList  post;
    SharedPreferences sp;
    SharedPreferences.Editor edit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        myDatabase=new MyDatabase(this);
        post=new ArrayList();

        recyclerView=(RecyclerView)findViewById(R.id.recycler);
        Bundle b=getIntent().getExtras();

        sp=getSharedPreferences("Login",MODE_PRIVATE);
       edit=sp.edit();

        try{
            s=b.getString("u");
            Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();

            edit.putString("user",s);
            edit.apply();
        }
        catch (Exception e)
        {

        }
        post=myDatabase.get();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        recyclerView.setAdapter(new MyAdapter(this,post));

       ;

    }

   //   public final   String u = getIntent().getExtras().getString("user");

    public void posts(View view) {
        Intent publish=new Intent(Home.this,Publish.class);
        String u =s;
        publish.putExtra("user2",u);
        startActivity(publish);
    }



                                    //APP BAR WITH MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {        // APP BAR WITH OPTIONS MENU
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:

                Toast.makeText(this, "logged out", Toast.LENGTH_SHORT).show();
                break;
            case R.id.view:
                Intent view=new Intent(Home.this,Viewpost.class);
                startActivity(view);
                Toast.makeText(this, "your posts", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }
    public void logout(MenuItem item) {
        edit.clear();
        edit.commit();
        finish();
        Intent i =new Intent(Home.this,Login.class);
        startActivity(i);
    }                 //-----------------APP BAR WITH OPTIONS MENU END*********

    @Override
    public void onBackPressed() {

        
    }
}
