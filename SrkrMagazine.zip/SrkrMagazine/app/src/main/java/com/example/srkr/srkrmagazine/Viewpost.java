package com.example.srkr.srkrmagazine;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class Viewpost extends AppCompatActivity {

    Cursor c;
    MyDatabase myDatabase;
    RecyclerView recyclerView2;
    ArrayList p;
    SharedPreferences sp;
    SharedPreferences.Editor edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewpost);


        sp=getSharedPreferences("Login",MODE_PRIVATE);
        String user=sp.getString("user","");

        p=new ArrayList();
        myDatabase=new MyDatabase(this);
        if(user.length()!=0){
            p= myDatabase.getposts(user);
        }
        recyclerView2=(RecyclerView)findViewById(R.id.view_re);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));
        recyclerView2.setHasFixedSize(true);
        recyclerView2.setAdapter(new MyAdapter2(this,p));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent publish=new Intent(Viewpost.this,Home.class);
        startActivity(publish);
    }
}
