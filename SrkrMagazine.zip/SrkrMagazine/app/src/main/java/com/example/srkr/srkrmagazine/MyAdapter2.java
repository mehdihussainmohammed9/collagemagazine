package com.example.srkr.srkrmagazine;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Hussain on 31-05-2018.
 */

class MyAdapter2 extends RecyclerView.Adapter<MyAdapter2.MyHolder2> {
    ArrayList post;
    Context ct;
    MyDatabase myDatabase;
    public MyAdapter2(Viewpost viewpost, ArrayList p) {
        this.ct=viewpost;
        this.post=p;
    }

    @Override
    public MyAdapter2.MyHolder2 onCreateViewHolder(ViewGroup parent, int viewType) {
        myDatabase=new MyDatabase(ct);
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        return new MyAdapter2.MyHolder2(view);
    }

    @Override
    public void onBindViewHolder(MyAdapter2.MyHolder2 holder, int position) {
        Getset2 posted=(Getset2)post.get(position);
        final String id=posted.getId().toString();
        holder.tit.setText(posted.getTitle().toString());
        holder.ca.setText(posted.getCategory().toString());
        holder.de.setText(posted.getDescription().toString());
        holder.author.setText(posted.getAuthor().toString());
        holder.linearLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                final AlertDialog.Builder builder=new AlertDialog.Builder(ct);
                builder.setTitle("Delete");
                builder.setMessage("Delete this article?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        long l=myDatabase.deletepost(id);
                        if(l>0){
                            ct.startActivity(new Intent(ct,Viewpost.class));
                            Toast.makeText(ct, "deleted", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(ct, "unable to delete post", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog=builder.create();
                dialog.show();
                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return post.size();
    }

    public class MyHolder2 extends RecyclerView.ViewHolder {
        TextView tit, ca, de, author;
        LinearLayout linearLayout;

        public MyHolder2(View itemView) {
            super(itemView);
            tit = (TextView) itemView.findViewById(R.id.title);
            ca = (TextView) itemView.findViewById(R.id.catitem);
            de = (TextView) itemView.findViewById(R.id.desitem);
            author = (TextView) itemView.findViewById(R.id.author);
            linearLayout=(LinearLayout)itemView.findViewById(R.id.linear);
        }

    }
}