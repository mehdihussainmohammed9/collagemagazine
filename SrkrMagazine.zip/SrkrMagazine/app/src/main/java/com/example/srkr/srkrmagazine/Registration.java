package com.example.srkr.srkrmagazine;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;

public class Registration extends AppCompatActivity {
    Button loginbtn;
    EditText namej, regidj, pswdj, repswdj;

    AwesomeValidation awesomeValidation;
    MyDatabase myDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        namej = (EditText) findViewById(R.id.name);
        regidj = (EditText) findViewById(R.id.regid);
        pswdj = (EditText) findViewById(R.id.password);
        repswdj = (EditText) findViewById(R.id.repassword);

        myDatabase=new MyDatabase(this);


    }

    public void login(View view) {

        String regexPassword = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}";
        namej = (EditText) findViewById(R.id.name);
        regidj = (EditText) findViewById(R.id.regid);
        pswdj = (EditText) findViewById(R.id.password);
        repswdj = (EditText) findViewById(R.id.repassword);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        awesomeValidation.addValidation(Registration.this, R.id.name, "[a-zA-Z\\s]+", R.string.err_name);
        awesomeValidation.addValidation(Registration.this, R.id.regid, "[0-9]{12}", R.string.err_reg);
        awesomeValidation.addValidation(Registration.this, R.id.password, regexPassword, R.string.err_password);
        awesomeValidation.addValidation(Registration.this, R.id.repassword, R.id.password, R.string.err_repassword);


        if (awesomeValidation.validate()) {

            String n = namej.getText().toString().trim();
            String r = regidj.getText().toString();
            String p = pswdj.getText().toString();



            myDatabase.insertData(n, r, p);
        }
        else {
            Toast.makeText(this, "Enter the details", Toast.LENGTH_SHORT).show();
        }


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this,Login.class));
    }

}

