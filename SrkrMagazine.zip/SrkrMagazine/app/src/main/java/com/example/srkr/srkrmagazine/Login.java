package com.example.srkr.srkrmagazine;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;

public class Login extends AppCompatActivity  {
    EditText useridj,loginpasswordj;
    Button loginj;
    AwesomeValidation awesomeValidation;

    ProgressDialog pd;
    ProgressBar pbar;

    MyDatabase helper;

    SharedPreferences sp;
    SharedPreferences.Editor edit;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        pbar=(ProgressBar)findViewById(R.id.progd);

        useridj=(EditText)findViewById(R.id.userid);
        loginpasswordj=(EditText)findViewById(R.id.loginPassword);
        helper=new MyDatabase(this);



        sp=getSharedPreferences("Login",MODE_PRIVATE);
        if(sp.getString("user","").equals("")){

        }else {
            Intent l1=new Intent(Login.this,Home.class);
            startActivity(l1);
        }

    }
    public void regis(View view) {
        Intent l1=new Intent(Login.this,Registration.class);
        startActivity(l1);
    }


    @Override
    public void onBackPressed() {

    }





    public void login(View view) {
        String regexPassword = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}";
        awesomeValidation=new AwesomeValidation(ValidationStyle.BASIC);

        awesomeValidation.addValidation(Login.this, R.id.userid, "[0-9]{12}", R.string.err_userid);
        awesomeValidation.addValidation(Login.this, R.id.loginPassword, regexPassword, R.string.err_password);


        if (awesomeValidation.validate()) {

            String u = useridj.getText().toString();
            String p = loginpasswordj.getText().toString();
            helper.login(u, p);
            pbar.setVisibility(View.VISIBLE);
        } else {
            Toast.makeText(this, "Enter the details", Toast.LENGTH_SHORT).show();
        }
    }
}

