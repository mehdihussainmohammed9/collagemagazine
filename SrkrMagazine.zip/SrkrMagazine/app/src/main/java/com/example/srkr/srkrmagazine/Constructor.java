package com.example.srkr.srkrmagazine;

import android.provider.BaseColumns;

public class Constructor {
    public static final String DATABASE_NAME="magazine.db";
    public static final String TABLE_NAME="registration";
    public static final String  TABLE_ART="articles";
    public static final int DB_VERSION=1;

        public class TableColums implements BaseColumns{
            public static final String REGID="regid";
            public static final String NAME="name";
            public static final String PASSWORD="password";
        }
        // ----------for articals insert
        public class TableColumsart implements BaseColumns{
            public static final String ID="id";
            public static final String TITLE="title";
            public static final String AUTHOR="author";
            public static final String CATEGORY="category";
            public static final String DESCRIPTION="description";
         //   public static final String IMAGE="image";
            public static final String REGID="regid";
        }
    public static final String CREATE_TABLE="CREATE TABLE "+TABLE_NAME+"("+TableColums.REGID+" TEXT PRIMARY KEY,"+TableColums.NAME+" TEXT,"+TableColums.PASSWORD+" TEXT);";
    public static final String TABLE_UPDATE="DROP TABLE IF EXISTS "+TABLE_NAME;
                                          //FOR ARTICAL TABLE
    public static final String CREATE_ART="CREATE TABLE "+TABLE_ART+"("+TableColumsart.ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+TableColumsart.TITLE+" TEXT,"+TableColumsart.AUTHOR+" TEXT,"+TableColumsart.CATEGORY+" TEXT,"+TableColumsart.DESCRIPTION+" TEXT,"+TableColumsart.REGID+" TEXT);";
    public static final String TABLEART_UPDATE="DROP TABLE IF EXISTS "+TABLE_ART;

}