package com.example.srkr.srkrmagazine;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * Created by Hussain on 16-03-2018.
 */

public class MyDatabase extends SQLiteOpenHelper {
    SQLiteDatabase WRITEDATA, READDATA;
    Context ct;
    private SQLiteDatabase db;
    Cursor c;
    Constructor constructor;


    public MyDatabase(Context context) {
        super(context, Constructor.DATABASE_NAME, null, 1);
        this.ct = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Constructor.CREATE_TABLE);
        db.execSQL(Constructor.CREATE_ART);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(Constructor.TABLE_UPDATE);
        db.execSQL(Constructor.TABLEART_UPDATE);
        onCreate(db);

    }



    public void insertData(String n, String r, String p) {

        WRITEDATA = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Constructor.TableColums.REGID, r);
        values.put(Constructor.TableColums.NAME, n);
        values.put(Constructor.TableColums.PASSWORD, p);
        long s = WRITEDATA.insert(Constructor.TABLE_NAME, null, values);
        if (s > 0) {
            Toast.makeText(ct, "Registration successful", Toast.LENGTH_SHORT).show();
            ct.startActivity(new Intent(ct, Login.class));
        }else {
            Toast.makeText(ct, "You already Registerd Please login", Toast.LENGTH_SHORT).show();
        }

    }

    public void insertart(String tit, String aut, String selected_item, String des, String user){
        WRITEDATA = getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(Constructor.TableColumsart.TITLE,tit);
        values.put(Constructor.TableColumsart.AUTHOR,aut);
        values.put(Constructor.TableColumsart.CATEGORY,selected_item);
        values.put(Constructor.TableColumsart.DESCRIPTION,des);
       // values.put(Constructor.TableColumsart.IMAGE,im);
        values.put(Constructor.TableColumsart.REGID,user);
        long a=WRITEDATA.insert(Constructor.TABLE_ART,null,values);
        if (a > 0) {
            Toast.makeText(ct, " Your artical posted", Toast.LENGTH_SHORT).show();
            ct.startActivity(new Intent(ct, Home.class));

        }
        else {
            Toast.makeText(ct, "not posted", Toast.LENGTH_SHORT).show();
        }
    }


    public long login(String u, String p) {

        READDATA = getReadableDatabase();
        Cursor c = READDATA.rawQuery("select password from registration where regid='"+u+"';", null);

        while (c.moveToFirst()) {
            String password = c.getString(0);

            if (p.equals(password)) {
            Intent i=new Intent(ct,Home.class);
            i.putExtra("u",u);

                ct.startActivity(i);


            } else {
                Toast.makeText(ct, "Login failed", Toast.LENGTH_SHORT).show();
            }
            return 0;
        }
        return 0;
    }
     public ArrayList get() {
         READDATA = getReadableDatabase();
         ArrayList post=new ArrayList();
         Cursor c =READDATA.rawQuery("select * from articles order by id DESC", null);
         while (c.moveToNext() ) {
             String id = c.getString(0);
             String title = c.getString(1);
             String author = c.getString(2);
             String category = c.getString(3);
             String description = c.getString(4);
             String regid = c.getString(5);
             post.add(new Getset(id,title,category,description,author));


         }


        return post;
     }

    public ArrayList getposts(String user) {
        READDATA = getReadableDatabase();

        ArrayList post=new ArrayList();
        Cursor c =READDATA.rawQuery("select * from articles where regid='"+user+"';", null);
        while (c.moveToNext()) {
            String id = c.getString(0);
            String title = c.getString(1);
            String author = c.getString(2);
            String category = c.getString(3);
            String description = c.getString(4);
            String regid = c.getString(5);
            Toast.makeText(ct, ""+regid, Toast.LENGTH_SHORT).show();
             post.add(new Getset2(id,title, category, description, author));


        }

        return post;
    }

    public long deletepost(String which) {
        WRITEDATA = getWritableDatabase();
       long l= WRITEDATA.delete(Constructor.TABLE_ART,"id=?",new String[]{which});
       return l;
    }
}









