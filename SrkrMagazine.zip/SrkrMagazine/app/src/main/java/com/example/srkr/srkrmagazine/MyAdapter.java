package com.example.srkr.srkrmagazine;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Hussain on 24-04-2018.
 */

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyHolder> {
    ArrayList post;
    Context ct;
    public MyAdapter(Home home, ArrayList post)
    {
        this.ct=home;
        this.post=post;
    }
    @Override
    public MyAdapter.MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item,parent,false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(MyAdapter.MyHolder holder, int position) {

        Getset posted=(Getset)post.get(position);

        holder.tit.setText(posted.getTitle().toString());
        holder.ca.setText(posted.getCategory().toString());
        holder.de.setText(posted.getDescription().toString());
        holder.author.setText(posted.getAuthor().toString());
    }

    @Override
    public int getItemCount() {
        return post.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView tit,ca,de,author;
        public MyHolder(View itemView) {
            super(itemView);
            tit=(TextView)itemView.findViewById(R.id.title);
            ca=(TextView)itemView.findViewById(R.id.catitem);
            de=(TextView)itemView.findViewById(R.id.desitem);
            author=(TextView)itemView.findViewById(R.id.author);}
    }
}
