package com.example.srkr.srkrmagazine;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.nightonke.boommenu.BoomMenuButton;

import java.io.ByteArrayOutputStream;


public class Publish extends AppCompatActivity {

    String[] cat = {"Select", "education", "sports", "innovatiove", "entertainment", "Internships", "Academics", "Campus"};
    BoomMenuButton menuButton;
    private static final int PICK_IMAGE = 100;
    ImageView imagej;
    Uri imageUri;
    EditText titlej, authorj, descriptj;
    String selected, img;
    MyDatabase myDatabase;
    ByteArrayOutputStream byteArrayOutputStream;
    String encodedImageString;
    SharedPreferences sp;
    SharedPreferences.Editor edit;
    String user;
    AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish);
        //   imagej=(ImageView)findViewById(R.id.image);
        titlej = (EditText) findViewById(R.id.title);
        authorj = (EditText) findViewById(R.id.author);
        descriptj = (EditText) findViewById(R.id.descripition);
        sp = getSharedPreferences("Login", MODE_PRIVATE);
        edit = sp.edit();
        user = sp.getString("user", "");

        Bundle b = getIntent().getExtras();
        String s = b.getString("user2");

        myDatabase = new MyDatabase(this);
        Spinner Myspinner = (Spinner) findViewById(R.id.spin);  //==========================spinner
        ArrayAdapter<String> myAdapter2 = new
                ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cat);
        myAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Myspinner.setAdapter(myAdapter2);
        Myspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selected = cat[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //----------------Boommenu-----------------
     /*   menuButton = (BoomMenuButton) findViewById(R.id.btupload);


            SimpleCircleButton.Builder builder = new SimpleCircleButton.Builder()
                    .normalImageRes(R.drawable.addpic).listener(new OnBMClickListener() {
                        @Override
                        public void onBoomButtonClick(int index) {
                            Intent cam =new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivityForResult(cam,0);
                            Toast.makeText(Publish.this, "camera clicked", Toast.LENGTH_SHORT).show();
                        }
                    });
        SimpleCircleButton.Builder builder1 = new SimpleCircleButton.Builder()
                .normalImageRes(R.drawable.photos).listener(new OnBMClickListener() {
                    @Override
                    public void onBoomButtonClick(int index) {
                        Intent photos =new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                        startActivityForResult(photos,PICK_IMAGE);
                        Toast.makeText(Publish.this, "Gallary clicked", Toast.LENGTH_SHORT).show();
                    }
                });
            menuButton.addBuilder(builder);
            menuButton.addBuilder(builder1);*/

    }
    // to pick a image
  /*  @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            if(requestCode==0){
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                Bitmap bitmap=(Bitmap)data.getExtras().get("data");
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] b = baos.toByteArray();
           //     encodedImageString = Base64.encodeToString(b, Base64.DEFAULT);
                imagej.setImageBitmap(bitmap);

            }else if(requestCode==PICK_IMAGE){
                imageUri= data.getData();
                imagej.setImageURI(imageUri);
            }
        }

    }*/
    //------------app bar with options menu----------

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menup, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:
                Toast.makeText(this, "logged out", Toast.LENGTH_SHORT).show();
                break;
            case R.id.view:
                startActivity(new Intent(Publish.this, Viewpost.class));
                Toast.makeText(this, "Your Articles", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    public void logout(MenuItem item) {
        edit.clear();
        edit.commit();
        finish();
        Intent i = new Intent(Publish.this, Login.class);
        startActivity(i);
    }

    public void publish(View view) {
        titlej = (EditText) findViewById(R.id.title);
        authorj = (EditText) findViewById(R.id.author);
        descriptj = (EditText) findViewById(R.id.descripition);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        awesomeValidation.addValidation(Publish.this, R.id.title, "[a-zA-Z0-9\\s]+", R.string.titlea);
        awesomeValidation.addValidation(Publish.this, R.id.author, "[a-zA-Z0-9\\s]+", R.string.authora);
        awesomeValidation.addValidation(Publish.this, R.id.descripition, "[a-zA-Z0-9\\s]+", R.string.descpa);

        if (awesomeValidation.validate()) {

            if (selected.equals("Select")) {
                Toast.makeText(Publish.this, "Please select anyone", Toast.LENGTH_SHORT).show();
            } else {
                String tit = titlej.getText().toString();
                String aut = authorj.getText().toString();
                String selected_item = selected;
                String des = descriptj.getText().toString();
                // String im =img;
                myDatabase.insertart(tit, aut, selected_item, des, user);
                //  Toast.makeText(this, "Your article will post soon", Toast.LENGTH_SHORT).show();

            }
        } else {
            Toast.makeText(this, "enter proper details", Toast.LENGTH_SHORT).show();
        }

    }
}
